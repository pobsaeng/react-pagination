# react-pagination-example

React - Pagination Example with Logic like Google

To see a demo and further details go to http://jasonwatmore.com/post/2017/03/14/react-pagination-example-with-logic-like-google